<?php
/** @package    Ercco::Model::DAO */

/** import supporting libraries */
require_once("verysimple/Phreeze/Criteria.php");

/**
 * UsuarioCriteria allows custom querying for the Usuario object.
 *
 * WARNING: THIS IS AN AUTO-GENERATED FILE
 *
 * This file should generally not be edited by hand except in special circumstances.
 * Add any custom business logic to the ModelCriteria class which is extended from this class.
 * Leaving this file alone will allow easy re-generation of all DAOs in the event of schema changes
 *
 * @inheritdocs
 * @package Ercco::Model::DAO
 * @author ClassBuilder
 * @version 1.0
 */
class UsuarioCriteriaDAO extends Criteria
{

	public $IdUsuario_Equals;
	public $IdUsuario_NotEquals;
	public $IdUsuario_IsLike;
	public $IdUsuario_IsNotLike;
	public $IdUsuario_BeginsWith;
	public $IdUsuario_EndsWith;
	public $IdUsuario_GreaterThan;
	public $IdUsuario_GreaterThanOrEqual;
	public $IdUsuario_LessThan;
	public $IdUsuario_LessThanOrEqual;
	public $IdUsuario_In;
	public $IdUsuario_IsNotEmpty;
	public $IdUsuario_IsEmpty;
	public $IdUsuario_BitwiseOr;
	public $IdUsuario_BitwiseAnd;
	public $Nome_Equals;
	public $Nome_NotEquals;
	public $Nome_IsLike;
	public $Nome_IsNotLike;
	public $Nome_BeginsWith;
	public $Nome_EndsWith;
	public $Nome_GreaterThan;
	public $Nome_GreaterThanOrEqual;
	public $Nome_LessThan;
	public $Nome_LessThanOrEqual;
	public $Nome_In;
	public $Nome_IsNotEmpty;
	public $Nome_IsEmpty;
	public $Nome_BitwiseOr;
	public $Nome_BitwiseAnd;
	public $Senha_Equals;
	public $Senha_NotEquals;
	public $Senha_IsLike;
	public $Senha_IsNotLike;
	public $Senha_BeginsWith;
	public $Senha_EndsWith;
	public $Senha_GreaterThan;
	public $Senha_GreaterThanOrEqual;
	public $Senha_LessThan;
	public $Senha_LessThanOrEqual;
	public $Senha_In;
	public $Senha_IsNotEmpty;
	public $Senha_IsEmpty;
	public $Senha_BitwiseOr;
	public $Senha_BitwiseAnd;

}

?>